export const colors = {
  background: "#F5F5DC", // Beige background
  primary: " rgba(59, 49, 149, 1)",    // Purple text/buttons
  secondary: "#FFFFFF",   // White accents
  text: "#372792ff",       // Purple text
  card: "#FFFFFF",        // White cards / containers
};
